package com.cg.ebill.dto;

public class BillDB {

	private double billNum	, curReading, unitConsumed, netAmount;
	private long consumerNum;
	private String month;
	
	
	public BillDB() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BillDB(double billNum, double curReading,
			double unitConsumed, double netAmount, long consumerNum) {
		super();
		this.billNum = billNum;
		this.curReading = curReading;
	
		this.unitConsumed = unitConsumed;
		this.netAmount = netAmount;
		this.consumerNum = consumerNum;
	}

	public double getBillNum() {
		return billNum;
	}

	public void setBillNum(double billNum) {
		this.billNum = billNum;
	}

	public double getCurReading() {
		return curReading;
	}

	public void setCurReading(double curReading) {
		this.curReading = curReading;
	}

	public double getUnitConsumed() {
		return unitConsumed;
	}

	public void setUnitConsumed(double unitConsumed) {
		this.unitConsumed = unitConsumed;
	}

	public double getNetAmount() {
		return netAmount;
	}

	public void setNetAmount(double netAmount) {
		this.netAmount = netAmount;
	}

	public long getConsumerNum() {
		return consumerNum;
	}

	public void setConsumerNum(long consumerNum) {
		this.consumerNum = consumerNum;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}


	
}
