package com.cg.util;

import java.sql.Connection;




import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;



public class DbUtil {

	static Connection conn=null;
	public static Connection obtainConnection(){
		
		InitialContext context;
		try {
			context = new InitialContext();
			DataSource source = (DataSource) context.lookup("java:/OracleDS");
			conn = source.getConnection();
		} catch (NamingException |SQLException e) {
	
			//throw new UsersException("Problem in Connection...");
			
		} 
		
		return conn;
	}
	
}
