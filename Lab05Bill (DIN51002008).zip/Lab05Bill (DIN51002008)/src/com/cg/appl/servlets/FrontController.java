package com.cg.appl.servlets;

import java.io.IOException;
import java.sql.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.appl.Services.UserMasterServices;
import com.cg.appl.Services.UserMasterServicesImpl;
import com.cg.appl.daos.UserMasterDaoImpl;
import com.cg.appl.entities.BillDetails;
import com.cg.appl.entities.Consumers;
import com.cg.appl.entities.User;
import com.cg.appl.exceptions.UserException;


@WebServlet("*.do")
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserMasterServices services;
	private RequestDispatcher dispatch;
	private UserMasterDaoImpl dao;
	private String nextJsp;
	String message = null;
	ServletContext ctx = null;

	public void init() throws ServletException {
		ctx = super.getServletContext();
		services = new UserMasterServicesImpl();
		dao = new UserMasterDaoImpl();
	}

	private void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String path = request.getServletPath();
		System.out.println("path: " + path);	//not to use SOP
		ctx.log("path: " + path);  			//logger from wildfly
		switch (path) {
		case "/login.do": {
			nextJsp = "login.jsp";
			break;
		}//End of case for login.do
		case "/authenticate.do": {
			System.out.println("in authenticate....");
			String userName = request.getParameter("userName");
			String password = request.getParameter("password");
			System.out.println(userName+" "+password);

			try {
				boolean isAuthenticated = services.isUserAuthenticated(userName, password);
				if (isAuthenticated) {
					//start a session
					User user = services.getUserDetails(userName);	
					HttpSession session = request.getSession(true);	// If session already exists still creates a new session
					System.out.println(session.getId());
					session.setAttribute("user", user);		// Available for all the servlets and jsp, assign session scope
					// System.out.println("Yes");
					//nextJsp = "/mainMenu.jsp";
					nextJsp = "/index.html";
				} else {
					message = "Wrong credentials, Enter again";
					request.setAttribute("errorMsg", message);

					// System.out.println("NO");
					nextJsp = "login.jsp";
				}
			} catch (UserException e) {
				message = "User name does not exists.";
				request.setAttribute("errorMsg", message);
				ctx.log(e.getMessage());		//logging
				nextJsp = "error.jsp";

			}
			break;
		}//End of case for authenticate.do
		
		case "/showAll.do" :{
			System.out.println("inshow all .do");
			List<Consumers> cList = null;
			
			try {
				cList = services.ShowAll();
				request.setAttribute("data", cList);
				nextJsp = "show_consumers.jsp";
			} catch (UserException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//System.out.println(myList);
			
			break;
		}
		case "/showbilldetails.do" :{
			List<BillDetails> cList = null;
			String data = request.getQueryString();
			String cid = data.substring(3, 9);
			System.out.println(cid);
			int consumerid = Integer.parseInt(cid);
			//System.out.println(consumerid);
			try {
				cList = services.showBilDetails(consumerid);
				System.out.println("in controller"+cList);
				request.setAttribute("cid", consumerid);
				request.setAttribute("data", cList);
				nextJsp = "show_bills.jsp";
			} catch (UserException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		}
		case "/calculate.do" :{
			System.out.println("In calculate.do");
			float fixedCharge = 100f;
			int cnumber= Integer.parseInt(request.getParameter("number"));
			int consumer_no = dao.isvalid(cnumber);			//to check consumer number from db
			System.out.println("result: "+ consumer_no );
			request.setAttribute("c_number", consumer_no);
			if(consumer_no > 0){
			float LMMR = Float.parseFloat(request.getParameter("lmmr"));
			float CMMR =  Float.parseFloat(request.getParameter("cmmr"));
			System.out.println(cnumber+" "+LMMR+" "+CMMR);
			if(CMMR<LMMR){
				request.setAttribute("msg", "current reading cannot be less than last month meter reading.");
				nextJsp = "mainMenu.jsp";
			}
			else{
				
				float unitConsumed =CMMR-LMMR;
				float netAmount = unitConsumed * 1.15f + fixedCharge;
				System.out.println(netAmount);	
				
				java.util.Date d = new java.util.Date(); //date conversion
				long time = d.getTime();
				Date date = new Date(time);
				
				BillDetails bd = new BillDetails();
				bd.setConsumer_num(cnumber);
				bd.setCur_reading(CMMR);
				bd.setUnitConsumed(unitConsumed);
				bd.setNetAmount(netAmount);
				bd.setBill_date(date);
				
				try {
					int billId = services.addBillDetails(bd);
					System.out.println("Bill id:"+billId);
					request.setAttribute("data", bd);
					//request.setAttribute("billdata", billId);
					nextJsp = "billsuccess.jsp";
				} catch (UserException e) {
					e.printStackTrace();
				}
				
			}}
			else {
				request.setAttribute("consumer_no", cnumber);
				request.setAttribute("errorMsg", "Invalid consumer number");
				nextJsp = "error.jsp";
			}
			break;
		}
		
		case "logout.do" : {
			HttpSession session = request.getSession(false); //expecting already created session
			session.invalidate(); // Destroys a session.
			nextJsp = "login.jsp";
			break;
		}
		}
		dispatch = request.getRequestDispatcher(nextJsp);
		dispatch.forward(request, response);
	}


	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	public void destroy() {
		services = null;
	}

}