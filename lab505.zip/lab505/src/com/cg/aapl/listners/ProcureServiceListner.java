package com.cg.aapl.listners;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import com.cg.aapl.exceptions.UserException;
import com.cg.aapl.services.UserMasterServices;
import com.cg.aapl.services.UserMasterServicesImpl;

@WebListener
public class ProcureServiceListner implements ServletContextListener {

	private UserMasterServices services;
	private ServletContext ctx = null;
    public void contextInitialized(ServletContextEvent event)  {
    	
    ctx= event.getServletContext();
    	try {
			services = new UserMasterServicesImpl();// one object is created
			ctx.setAttribute("services", services);//many front controller can get its ref. it will go to front controller.
		} catch (UserException e) {

			
			
			ctx.log(e.getMessage());

		} 
    }
    
    
    public void contextDestroyed(ServletContextEvent arg0)  { 
        
    }

	
}
