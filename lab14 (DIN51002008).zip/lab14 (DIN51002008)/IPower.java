package lab14;

public interface IPower {
	int add(int x, int y);

}
