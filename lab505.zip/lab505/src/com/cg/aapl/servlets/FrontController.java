package com.cg.aapl.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;





import com.cg.aapl.entities.Bill;

import com.cg.aapl.entities.User;
import com.cg.aapl.exceptions.UserException;
import com.cg.aapl.services.UserMasterServices;


@WebServlet("*.do")
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserMasterServices services;
	private RequestDispatcher dispatch;
	private String nextJsp;
	String message = null;
	ServletContext ctx = null;
	private Bill bill;
	public void init() throws ServletException {
		 ctx = super.getServletContext();
		services = (UserMasterServices)ctx.getAttribute("services");//it will come from listner.
		bill= new Bill();
	}

	private void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException, UserException {
		double FixedCharge;
		
		String FixedChargeStr = ctx.getInitParameter("FixedCharge");
		FixedCharge= Float.parseFloat(FixedChargeStr);

		String command = request.getServletPath();
		ctx.log("command:" + command);

		switch (command) {
		case "/login.do": {
			nextJsp = "/login.jsp";
			break;
		}
		case "/authenticate.do": {

			String userName = request.getParameter("userName");
			String password = request.getParameter("password");

			boolean isAuthenticated;

			try {
				isAuthenticated = services.isUserAuthenticated(userName,
						password);
				if (isAuthenticated) {
					// Start a session.
					User user = services.getUserDetails(userName);
					HttpSession session = request.getSession(true);// here
																	// command
																	// is done
																	// for
																	// session
																	// construction
					System.out.println(session.getId());
					session.setAttribute("user", user);
					nextJsp = "/mainMenu.jsp";
					// control will go to mainMenujsp
				} else {

					// System.out.println("NO");
					message = "wrong credentials Enter again";
					request.setAttribute("errormsg", message);// will send error
																// to login.jsp
					nextJsp = "/login.jsp";
					// dispatch.forward(request, resp);//control will go to
					// login
				}
			} catch (UserException e) {
				message = "Username does not exist.";
				request.setAttribute("errormsg", message);
				ctx.log(e.getMessage());//loggerfile

				nextJsp = "/error.jsp";
				// dispatch.forward(request, resp);

				// e.printStackTrace();
			}

			break;
		}// end of case for authenticate

		case "/logout.do": {

			HttpSession session = request.getSession(false); // it can be true
																// but true is
																// given where
																// session is
																// created/onesession
																// per user
			session.invalidate();// destroys a session.
			nextJsp = "/login.jsp";
			break;

		}
		case "/calculateBill.do":{
		
			String consumerN=request.getParameter("consumerNumber");
			System.out.println(consumerN);
			int consumerNumber=Integer.parseInt(consumerN);
			boolean isValid=services.isValid(consumerNumber);
			if(isValid){
			String lastMon=request.getParameter("lastMonth");
			double lastMonth=Double.parseDouble(lastMon);
			String  cur=request.getParameter("current");
			double current= Double.parseDouble(cur);
				if(current>lastMonth){
				double unitConsumed=(current)-(lastMonth);
				double netAmount=(unitConsumed*1.15)+ FixedCharge;
				System.out.println(FixedCharge);
				bill.setConsumer_num(consumerNumber);
				bill.setCur_reading(current);
				bill.setNetAmount(netAmount);
				bill.setUnitConsumed(unitConsumed);
				try {
					HttpSession session = request.getSession(false);
					int rec=services.insertBill(bill);
					System.out.println(rec);
					
					session.setAttribute("bill1", bill);
					nextJsp = "/display.jsp";
				} catch (UserException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				
		}
			else {
				message = "Lastmonth reading is smaller than Current mMonth";
				request.setAttribute("errormsg", message);
				nextJsp="/error.jsp";
		}
			} else{
				message = "invalid consumer number";
				request.setAttribute("errormsg", message);
				nextJsp="/error.jsp";
			}

		}
		
		
	}
		dispatch = request.getRequestDispatcher(nextJsp);
		dispatch.forward(request, response);
	}



	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request, response);
		} catch (UserException e) {
		
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

	public void destroy() {
		services = null;

	}
}
