package com.cg.aapl.doas;


import com.cg.aapl.entities.Bill;
import com.cg.aapl.entities.Consumer;
import com.cg.aapl.entities.User;
import com.cg.aapl.exceptions.UserException;

public interface UserMasterDao {
	User getUserDetails(String UserName) throws UserException;

	int insertBill(Bill bill) throws UserException;

	boolean isValid(int consumerNumber)  throws UserException;

	

	

}
