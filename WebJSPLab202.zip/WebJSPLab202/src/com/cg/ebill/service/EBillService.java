package com.cg.ebill.service;

import java.util.List;

import com.cg.ebill.dto.BillDB;
import com.cg.ebill.dto.BillDTO;
import com.cg.ebill.dto.ConsumerDTO;
import com.cg.ebill.exception.UserException;

public interface EBillService {

	BillDTO calcEBill(BillDTO eBill, ConsumerDTO consumer);
	
	boolean isUserAuthenticated(String userName, String password) throws UserException;
	
	ConsumerDTO getConsumer(long consumerNo);
	
	List<ConsumerDTO> getConsumerList();
	
	List<BillDB> getConsumerBills(long consumerNo);
	
	boolean validateUserName(String name);
	boolean validatePassword(String pwd);
	boolean validateConsumerNumber(Long cNO);
	boolean validateReading(Double lmmr, Double cmmr);
	
}