package com.cg.aapl.doas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.aapl.entities.Bill;
import com.cg.aapl.entities.Consumer;
import com.cg.aapl.entities.User;
import com.cg.aapl.exceptions.UserException;
import com.cg.aapl.util.JdbcUtil;
import com.cg.aapl.util.JndiUtil;

public class UserMasterDaoImpl implements UserMasterDao {

	// private JdbcUtil util;
	private JndiUtil util;

	public UserMasterDaoImpl() throws UserException {
		util = new JndiUtil();

	}

	@Override
	public User getUserDetails(String userName) throws UserException {
		Connection connect = null;
		PreparedStatement stmp = null;
		ResultSet rs = null;
		String qry = "SELECT PASSWORD,USERFNAME FROM USERS WHERE USERNAME=?";
		try {
			connect = util.getConnection();
			stmp = connect.prepareStatement(qry);
			stmp.setString(1, userName);
			rs = stmp.executeQuery();
			if (rs.next()) {

				String password = rs.getString("PASSWORD");
				String fullname = rs.getString("USERFNAME");
				User user = new User(userName, password, fullname);
				return user;
			} else {
				throw new UserException("Username wrong");
			}
		} catch (SQLException e) {
			throw new UserException("Jdbc Failed", e);

		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (stmp != null) {
					stmp.close();
				}
				if (connect != null) {
					connect.close();
				}
			} catch (SQLException e) {
				throw new UserException("Jdbc connection Failed", e);

			}
		}

	}

	@Override
	public int insertBill(Bill bill) throws UserException {
		int bill_num = getNum();
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;

		int rec = 0;
		String qry = "INSERT INTO BillDetails VALUES(?,?,?,?,?,sysdate)";
		try {
			con = util.getConnection();
			pst = con.prepareStatement(qry);
			pst.setInt(1, bill_num);
			pst.setInt(2, bill.getConsumer_num());
			pst.setDouble(3, bill.getCur_reading());
			pst.setDouble(4, bill.getUnitConsumed());
			pst.setDouble(5, bill.getNetAmount());
			rec = pst.executeUpdate();
		} catch (SQLException e) {

			e.printStackTrace();
		}
		System.out.println(rec);
		if (pst != null) {
			try {
				pst.close();
			} catch (SQLException e) {

				throw new UserException("Jdbc connection Failed", e);
			}
		}
		if (con != null) {
			try {
				con.close();
			} catch (SQLException e) {

				throw new UserException("Jdbc connection Failed", e);
			}
		}
		return bill_num;
	}

	
	
	public int getNum() throws UserException {
		Connection con = null;
		PreparedStatement pst = null;
		int bill_num=0;
		String query="select seq_bill_num.nextval from dual";
		try {
			con=util.getConnection();
			pst=con.prepareStatement(query);
			ResultSet res=pst.executeQuery();
			while(res.next()){
				
				bill_num=res.getInt(1);
				System.out.println("bill_num"+bill_num);
			}
		} catch (SQLException e) {
			
			throw new UserException(e);
		}
		

		return bill_num;

	}

	@Override
	public boolean isValid(int consumerNumber) throws UserException {
		Connection connect = null;
		PreparedStatement stmp = null;
		ResultSet rs = null;
		Consumer cons= new Consumer();
		String query="SELECT consumer_num from consumers where consumer_num=?";
		try {
			connect = util.getConnection();
			stmp = connect.prepareStatement(query);
			stmp.setInt(1,consumerNumber);
			rs = stmp.executeQuery();
			if (rs.next()) {

				int consumerNumber1 = rs.getInt("consumer_num");
				
				return true;
			}
			
		} catch (SQLException e) {
			System.out.println(e);
			throw new UserException("Jdbc Failed", e);
		}
		finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (stmp != null) {
					stmp.close();
				}
				if (connect != null) {
					connect.close();
				}
			} catch (SQLException e) {
				throw new UserException("Jndi connection Failed", e);

			}
		}
		return false;
	}
}
