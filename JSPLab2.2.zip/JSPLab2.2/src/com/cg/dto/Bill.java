package com.cg.dto;

public class Bill {

	private int c_no,last_read,curr_read,unit_con,net_Amt;


	private String c_name;
	private String c_addr;
	
	public Bill() {
		super();
	}



	public Bill(int c_no, String c_name,String c_addr,int unit_con,int last_read, int curr_read) {
		super();
		this.c_no = c_no;
		this.last_read = last_read;
		this.curr_read = curr_read;
		this.unit_con = unit_con;
		this.last_read=last_read;
		this.c_name = c_name;
		this.c_addr = c_addr;
	}



	public String getC_name() {
		return c_name;
	}



	public void setC_name(String c_name) {
		this.c_name = c_name;
	}



	public String getC_addr() {
		return c_addr;
	}



	public void setC_addr(String c_addr) {
		this.c_addr = c_addr;
	}



	public int getUnit_con() {
		return unit_con;
	}



	public void setUnit_con(int unit_con) {
		this.unit_con = unit_con;
	}



	public int getNet_Amt() {
		return net_Amt;
	}



	public void setNet_Amt(int net_Amt) {
		this.net_Amt = net_Amt;
	}



	public int getC_no() {
		return c_no;
	}



	public void setC_no(int c_no) {
		this.c_no = c_no;
	}



	public int getLast_read() {
		return last_read;
	}



	public void setLast_read(int last_read) {
		this.last_read = last_read;
	}



	public int getCurr_read() {
		return curr_read;
	}



	public void setCurr_read(int curr_read) {
		this.curr_read = curr_read;
	}
	
	
}
