package com.cg.employeemanagement.util;

import java.sql.Connection;




import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.employeemanagement.exception.EmployeeException;

public class DbUtil {

	static Connection conn=null;
	public static Connection obtainConnection() throws EmployeeException{
		
		InitialContext context;
		try {
			context = new InitialContext();
			DataSource source = (DataSource) context.lookup("java:/OracleDS");
			conn = source.getConnection();
		} catch (NamingException |SQLException e) {
	
			throw new EmployeeException("Problem in Connection...");
			
		} 
		
		return conn;
	}
	
}
