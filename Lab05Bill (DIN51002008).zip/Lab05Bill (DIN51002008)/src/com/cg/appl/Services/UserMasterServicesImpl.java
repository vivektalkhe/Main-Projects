package com.cg.appl.Services;

import java.util.List;

import com.cg.appl.daos.UserMasterDao;
import com.cg.appl.daos.UserMasterDaoImpl;
import com.cg.appl.entities.BillDetails;
import com.cg.appl.entities.Consumers;
import com.cg.appl.entities.User;
import com.cg.appl.exceptions.UserException;

public class UserMasterServicesImpl implements UserMasterServices {
	
	private UserMasterDao dao;
	
	public UserMasterServicesImpl(){
		dao = new UserMasterDaoImpl(); 
	}
			@Override
			public User getUserDetails(String userName) throws UserException {
				
				return dao.getUserDetails(userName);
			}
			@Override
			public boolean isUserAuthenticated(String userName, String password)
					throws UserException {
						return dao.isUserAuthenticated(userName, password);
				
			}
			@Override
			public int addBillDetails(BillDetails bd) throws UserException {
				return dao.addBillDetails(bd);
			}
			@Override
			public List<Consumers> ShowAll() throws UserException {
				return dao.showAll();
			}
			@Override
			public List<BillDetails> showBilDetails(int consumerid)
					throws UserException {
			return dao.showBilDetails(consumerid);
			}
			
	
}
