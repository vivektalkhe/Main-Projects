package com.cg.ebill.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.ebill.dto.BillDB;
import com.cg.ebill.dto.BillDTO;
import com.cg.ebill.dto.ConsumerDTO;
import com.cg.ebill.exception.BillException;
//import com.cg.ebill.exception.NullSessionException;
import com.cg.ebill.service.EBillService;
import com.cg.ebill.service.EBillServiceImpl;


@WebServlet("*.do")
public class EBillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    ConsumerDTO consumer;   
    BillDTO eBill;
    EBillService serviceRef;
    private RequestDispatcher dispatch;
    ServletContext ctx = null;
    
    public EBillController() throws BillException {
        super();
        consumer = new ConsumerDTO();
        eBill = new BillDTO();
        serviceRef = new EBillServiceImpl();
    }

    public void init() throws ServletException {
		ctx = super.getServletContext();
		serviceRef = (EBillService) ctx.getAttribute("services");
		try {
			serviceRef = new EBillServiceImpl();
			
		} catch (BillException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.processRequest(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.processRequest(request, response);
	}

	private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		boolean valid = false;
		String nextJsp = null;
		String path = request.getServletPath();
		
		if(path.equals("/login.do"))
		{
			nextJsp = "login.jsp";
			
		}
		
		if(path.equals("/authenticate.do"))
		{
			String userName = request.getParameter("userName");
			valid = serviceRef.validateUserName(userName);
			if(!valid)
			{
				nextJsp = "/failure.jsp";
				String message = "User Name Invalid !!!";
				request.setAttribute("errorMsg", message);
				dispatch = request.getRequestDispatcher(nextJsp);
				dispatch.forward(request,response);
			}
			String pwd = request.getParameter("password");
			valid = serviceRef.validatePassword(pwd);
			if(!valid)
			{
				nextJsp = "/failure.jsp";
				String message = "password Invalid !!!";
				request.setAttribute("errorMsg", message);
				dispatch = request.getRequestDispatcher(nextJsp);
				dispatch.forward(request,response);
			}
			
			try 
			{
				boolean isAuthenticated = serviceRef.isUserAuthenticated(userName, pwd);
				if(isAuthenticated)
				{//System.out.println("USer Authenticated");
					HttpSession session = request.getSession(true);
					session.setAttribute("userName", userName);
					nextJsp = "/index.html";
				}
				else
				{
					nextJsp = "/failure.jsp";
					String message = "Invalid Password !!!";
					request.setAttribute("errorMsg", message);
				}				
			} catch (com.cg.ebill.exception.UserException e) {
				
				/*dispatch = request.getRequestDispatcher("/error.jsp");
				dispatch.forward(request, response);*/
				nextJsp = "/failure.jsp";
				String message = "User Name does not exist !!!";
				request.setAttribute("errorMsg", message);
				
				//e.printStackTrace();
			}
			
		}
		
		if(path.equals("/userInfo.do"))
		{
			HttpSession session = request.getSession(false);
			System.out.println("IN userinfo .do");
			/*if(session.getAttribute(path)!=null)
			{*/
				Long consumerNo = Long.parseLong(request.getParameter("CNumber"));
				valid = serviceRef.validateConsumerNumber(consumerNo);
				if(!valid)
				{
					nextJsp = "/failure.jsp";
					String message = "Invalid Customer Number format!!!";
					request.setAttribute("errorMsg", message);
					dispatch = request.getRequestDispatcher(nextJsp);
					dispatch.forward(request,response);
				}
				double lastMonReading = Double.parseDouble(request.getParameter("LMMR"));
				double curMonReading = Double.parseDouble(request.getParameter("CMMR"));
				valid = serviceRef.validateReading(lastMonReading, curMonReading);
				if(!valid)
				{
					nextJsp = "/failure.jsp";
					String message = "Invalid Reading Values!!!";
					request.setAttribute("errorMsg", message);
					dispatch = request.getRequestDispatcher(nextJsp);
					dispatch.forward(request,response);
				}
				consumer.setConsumerNo(consumerNo);
				eBill.setLastReading(lastMonReading);
				eBill.setCurReading(curMonReading);
				
				eBill = serviceRef.calcEBill(eBill,consumer);
				if(eBill != null)
				{
					ConsumerDTO temp = serviceRef.getConsumer(consumerNo);
					session.setAttribute("consumer", temp);
					session.setAttribute("bill", eBill);
					
					nextJsp = "Info_View.jsp";
				}
				else
				{
					session.setAttribute("cNum", consumerNo);
					nextJsp = "/consumerNotFound.jsp";
				}
				
			/*}
			else
			{
				try {
					throw new NullSessionException("Session Expired !!!");
					
				} catch (NullSessionException e) {
					// TODO Auto-generated catch block
					//e.printStackTrace();
				}
			}*/
			
		}
		
		if(path.equals("/logout.do"))
		{
			HttpSession session = request.getSession(false);
			System.out.println(session.getId());
			session.invalidate(); //destroying session
			System.out.println(session.getId());
			System.out.println("logout Success !!!");
			nextJsp = "/login.jsp";
			
		}
		
		if(path.equals("/showConsumerList.do"))
		{
			HttpSession session = request.getSession(false);
			List<ConsumerDTO> cList = new ArrayList<ConsumerDTO>();
			cList = serviceRef.getConsumerList();
			session.setAttribute("consumerList", cList);
			nextJsp = "/show_ConsumerList.jsp";
			
		}		
		
		if(path.equals("/showBill.do"))
		{
			HttpSession session = request.getSession(false);
			List<BillDB> bList = new ArrayList<BillDB>();
			long cNo = Long.parseLong(request.getParameter("cNo"));
			valid = serviceRef.validateConsumerNumber(cNo);
			if(!valid)
			{
				nextJsp = "/failure.jsp";
				String message = "Invalid Customer Number format!!!";
				request.setAttribute("errorMsg", message);
				dispatch = request.getRequestDispatcher(nextJsp);
				dispatch.forward(request,response);
			}
			bList = serviceRef.getConsumerBills(cNo);
			session.setAttribute("Bills", bList);
			session.setAttribute("cNO", cNo);
			nextJsp = "/show_Bills.jsp";
			
		}
		
		if(path.equals("/searchConsumer.do"))
		{
			HttpSession session = request.getSession(false);
			ConsumerDTO tempCus = new ConsumerDTO();
			long cusNo = Long.parseLong(request.getParameter("cNumber"));
			valid = serviceRef.validateConsumerNumber(cusNo);
			if(!valid)
			{
				nextJsp = "/failure.jsp";
				String message = "Invalid Customer Number format!!!";
				request.setAttribute("errorMsg", message);
				dispatch = request.getRequestDispatcher(nextJsp);
				dispatch.forward(request,response);
			}
			tempCus = serviceRef.getConsumer(cusNo);
			session.setAttribute("consumer", tempCus);
			nextJsp = "/show_Consumer.jsp";
			
		}

		dispatch = request.getRequestDispatcher(nextJsp);
		dispatch.forward(request,response);
	}
	
}