package com.cg.aapl.entities;

import java.io.Serializable;

public class User  implements Serializable{

	
		private String UserName;
		private String password;
		private String userFullName;
		public User(String userName, String password, String userFullName) {
			super();
			UserName = userName;
			this.password = password;
			this.userFullName = userFullName;
		}
		public String getUserName() {
			return UserName;
		}
		public void setUserName(String userName) {
			UserName = userName;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getUserFullName() {
			return userFullName;
		}
		public void setUserFullName(String userFullName) {
			this.userFullName = userFullName;
		}
		
		
	

}
