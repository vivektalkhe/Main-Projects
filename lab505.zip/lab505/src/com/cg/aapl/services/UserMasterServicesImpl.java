package com.cg.aapl.services;

import com.cg.aapl.doas.UserMasterDao;
import com.cg.aapl.doas.UserMasterDaoImpl;
import com.cg.aapl.entities.Bill;
import com.cg.aapl.entities.User;
import com.cg.aapl.exceptions.UserException;

public class UserMasterServicesImpl implements UserMasterServices {
  private UserMasterDao dao;
  public UserMasterServicesImpl() throws UserException{
	  dao= new UserMasterDaoImpl();
  }
@Override
public User getUserDetails(String UserName) throws UserException {
	
	return dao.getUserDetails(UserName);
}
@Override
public boolean isUserAuthenticated(String UserName, String password)
		throws UserException {
	User user=	dao.getUserDetails(UserName);
			if(password.equals(user.getPassword())){
						return true;
				} else {
					return false;
				}


}
@Override
public int insertBill(Bill bill) throws UserException {
	
	return dao.insertBill(bill);
}
@Override
public boolean isValid(int consumerNumber) throws UserException  {
	return dao.isValid(consumerNumber);
	
	
}


}
	


