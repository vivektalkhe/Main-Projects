package com.cg.aapl.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import javax.activation.DataSource;

import oracle.jdbc.pool.OracleDataSource;

public class JdbcUtil {
   
	//private Properties props;
	private OracleDataSource dataSource;
	
	public JdbcUtil() {
		
		/*props=new Properties();
		InputStream is=null;*/
		try {
			/*is=new FileInputStream("D:\\Module 3\\module3Luna\\Web020LogInSimple\\src\\oracle111.properties");
			props.load(is);
			dataSource= new OracleDataSource();
			dataSource.setURL(props.getProperty("oracle.url"));
			dataSource.setUser(props.getProperty("oracle.uname"));
			dataSource.setPassword(props.getProperty("oracle.upass"));
			dataSource.setDriverType("oracle");*/
			dataSource= new OracleDataSource();
			dataSource.setURL("jdbc:oracle:thin:@10.125.6.62:1521:orcl11g");
			dataSource.setUser("labg104trg1");
			dataSource.setPassword("labg104oracle");
			dataSource.setDriverType("oracle");
			
		} /*catch (FileNotFoundException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} */catch (SQLException e) {
			e.printStackTrace();
		}
			
		/*finally {
			try {
				is.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}*/
	
	}
 public Connection getConnection() throws SQLException{
	 return dataSource.getConnection();
 }
@Override
protected void finalize() throws Throwable {
	dataSource.close();
	super.finalize();
}
 
 
}
