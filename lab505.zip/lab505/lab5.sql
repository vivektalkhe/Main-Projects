SELECT consumer_num from consumers where consumer_num=100002;
