package com.cg.appl.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;
import oracle.jdbc.pool.OracleDataSource;

public class JdbcUtil {
	
	//private Properties props;
	private OracleDataSource datasource;

	public JdbcUtil()  {
	
		/*props=new Properties();
		InputStream in=null;*/
		
		try {
			/*in = new FileInputStream("C:\\Users\\vtalkhe\\workspace\\Module3 Workspace\\Web020Login\\src\\oracle.properties");
			props.load(in);
			datasource=new OracleDataSource();
			datasource.setURL(props.getProperty("url"));
			datasource.setUser(props.getProperty("uname"));
			datasource.setPassword(props.getProperty("upass"));
			datasource.setDriverType(props.getProperty("oracle"));*/
			
			datasource=new OracleDataSource();
			datasource.setURL("jdbc:oracle:thin:@10.125.6.62:1521:ORCL11G");
			datasource.setUser("labg104trg17");
			datasource.setPassword("labg104oracle");
			datasource.setDriverType("oracle");
			
		} /*catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}*/ catch (SQLException e) {
			e.printStackTrace();
		}
		/*finally {
		try {
			in.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		}*/
	}
		
public Connection getConnection() throws SQLException
{
	return datasource.getConnection();
}
@Override
protected void finalize() throws Throwable {	
	datasource.close();
	super.finalize();
}		
}