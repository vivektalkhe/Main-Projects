package com.cg.aapl.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.aapl.exceptions.UserException;

public class JndiUtil {
	
	private DataSource datasource;
	
	public JndiUtil() throws UserException{
		try {
			Context cts = new InitialContext(); //get reference to remote jndi
			datasource= ( DataSource)cts.lookup("java:/OracleDS");
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new UserException("Failed to get JNDI context",e);
		}
	}
	 public Connection getConnection() throws SQLException{
		 return datasource.getConnection();
	 }
	
}
