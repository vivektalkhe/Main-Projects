package lab14;

public class PowerClass {

	public static void main(String[] args) {
		IPower p= (int x,int y) -> Math.pow(x, y);
		double result = p.add(3,2);
		System.out.println(result);
	}

}
