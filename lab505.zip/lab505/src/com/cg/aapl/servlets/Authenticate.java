package com.cg.aapl.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.aapl.exceptions.UserException;
import com.cg.aapl.services.UserMasterServices;
import com.cg.aapl.services.UserMasterServicesImpl;

@WebServlet("/authenticate")
public class Authenticate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserMasterServices services;

	public void init() throws ServletException {
		try {
			services = new UserMasterServicesImpl();
		} catch (UserException e) {
			
			e.printStackTrace();
		}

	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse resp)
			throws ServletException, IOException {
		String userName = request.getParameter("userName");
		String password = request.getParameter("password");
		RequestDispatcher dispatch= null;
		boolean isAuthenticated;
		String nextJsp=null;
		String message=null;
		try {
			isAuthenticated = services.isUserAuthenticated(userName, password);
			if (isAuthenticated) {
				//System.out.println("YES");
				nextJsp="/mainMenu.jsp";
				//control will go to mainMenujsp
			} else {

				//System.out.println("NO");
				message="wrong credentials Enter again";
				request.setAttribute("errormsg", message);//will send error to login.jsp
				nextJsp="/Login.jsp";
				//dispatch.forward(request, resp);//control will go to login
			}
		} catch (UserException e) {
			message="Username does not exist.";
			request.setAttribute("errormsg", message);
			
			nextJsp="/error.jsp";
			//dispatch.forward(request, resp);
			
			//e.printStackTrace();
		}
		
		dispatch= request.getRequestDispatcher(nextJsp);
		dispatch.forward(request, resp);

	}

	public void destroy() {

	}

}
