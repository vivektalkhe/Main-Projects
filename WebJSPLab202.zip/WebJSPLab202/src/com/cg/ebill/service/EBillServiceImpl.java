package com.cg.ebill.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.ebill.dao.EBillDAO;
import com.cg.ebill.dao.EBillDAOImpl;
import com.cg.ebill.dto.BillDB;
import com.cg.ebill.dto.BillDTO;
import com.cg.ebill.dto.ConsumerDTO;
import com.cg.ebill.dto.User;
import com.cg.ebill.exception.BillException;
import com.cg.ebill.exception.InvalidInputFormatException;
import com.cg.ebill.exception.UserException;

public class EBillServiceImpl implements EBillService {

	EBillDAO billDAORef;
	String s = null;
	Pattern pat = null;
	Matcher mat = null;
	
	public EBillServiceImpl() throws BillException {
		billDAORef = new EBillDAOImpl();
	}

	@Override
	public BillDTO calcEBill(BillDTO eBill, ConsumerDTO consumer) {
		BillDTO tempBill = new BillDTO();
		tempBill = billDAORef.calcEBill(eBill, consumer);
		if(tempBill != null)
		{
			return tempBill;
		}
		else
		{
			return null;
		}
	}

	@Override
	public boolean isUserAuthenticated(String userName, String password)
			throws UserException {
		User user = billDAORef.userAuthentication(userName);
		if(user.getPassword().equals(password))
		{
			System.out.println("Login success !!!");
			return true;
		}
		else
		{
			System.out.println("Login failure !!!");
			return false;
		}
	}

	@Override
	public ConsumerDTO getConsumer(long consumerNo) {
		
		ConsumerDTO tempC = new ConsumerDTO();
		
		tempC = billDAORef.getConsumer(consumerNo);
		if(tempC != null)
		{
			return tempC;
		}
		else
		{
			System.out.println("GEt consumer failed in Service");
			return null;
		}
		
	}

	@Override
	public List<ConsumerDTO> getConsumerList() {
		
		return billDAORef.getConsumerList();
	}

	@Override
	public List<BillDB> getConsumerBills(long consumerNo) {
		
		return billDAORef.getConsumerBills(consumerNo);
	}

	@Override
	public boolean validateUserName(String name) {
		
		if(!name.equals(null))
		{
			s = name;
			
			pat =  Pattern.compile("^//w+$");
			mat = pat.matcher(s);
			if(!mat.find())
			{
				System.out.println("Invalid Consumer Name !!!");
				try {
					throw new InvalidInputFormatException(s);
				} catch (InvalidInputFormatException e) {
					
					System.out.println("invalid Consumer Name !!!"+e);
				}
			}
			return true;
		}
		else
		{			
			return false;
		}
	}

	@Override
	public boolean validatePassword(String pwd) {
		if(!pwd.equals(null))
		{
			s = pwd;
			
			pat =  Pattern.compile("^[0-9a-zA-Z]{3}$");
			mat = pat.matcher(s);
			if(!mat.find())
			{
				System.out.println("Invalid Password Length !!!");
				try {
					throw new InvalidInputFormatException(s);
				} catch (InvalidInputFormatException e) {
					
					System.out.println("Invalid Password Length"+e);
				}
			}
			return true;
		}
		else
		{			
			return false;
		}
	}

	@Override
	public boolean validateConsumerNumber(Long cNO) {
		String cNo = cNO.toString();
		if(!cNo.equals(null))
		{
			s = cNo;
			
			pat =  Pattern.compile("^[1]{1}[0-9]{4}[0-9]{1}$");
			mat = pat.matcher(s);
			if(!mat.find())
			{
				System.out.println("Invalid Consumer Number !!!");
				try {
					throw new InvalidInputFormatException(s);
				} catch (InvalidInputFormatException e) {
					
					System.out.println("Consumer Number not as per reqD format !!!"+e);
				}
			}
			return true;
		}
		else
		{			
			return false;
		}
	}

	@Override
	public boolean validateReading(Double lmmr, Double cmmr) {
		String lastR = lmmr.toString();
		String currR = cmmr.toString();
		
		if((!lastR.equals(null))&&(!currR.equals(null))&&(lmmr>0)&&(cmmr>0))
		{
			if(lmmr<cmmr)
			{				
				pat =  Pattern.compile("^\\d+\\.\\d+$");
				mat = pat.matcher(lastR);
				if(!mat.find())
				{
					System.out.println("Invalid Last Month Reading !!!");
					try {
						throw new InvalidInputFormatException(s);
					} catch (InvalidInputFormatException e) {
						
						System.out.println("Invalid Last Month Reading !!!"+e);
					}
				}
				pat =  Pattern.compile("^\\d+\\.\\d+$");
				mat = pat.matcher(currR);
				if(!mat.find())
				{
					System.out.println("Invalid Current Month Reading !!!");
					try {
						throw new InvalidInputFormatException(s);
					} catch (InvalidInputFormatException e) {
						
						System.out.println("Invalid Current Month Reading !!!"+e);
					}
				}
				
				
				return true;
			}
			else
			{
				try {
					throw new InvalidInputFormatException(s);
				} catch (InvalidInputFormatException e) {
					
					System.out.println("Last month reading must be greater than current one !!!"+e);
				}
				return false;
			}
		}
		else
		{			
			return false;
		}
	}

}
