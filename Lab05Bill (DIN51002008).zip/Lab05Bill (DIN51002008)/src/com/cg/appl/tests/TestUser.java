package com.cg.appl.tests;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.appl.Services.UserMasterServices;
import com.cg.appl.Services.UserMasterServicesImpl;
import com.cg.appl.entities.User;
import com.cg.appl.exceptions.UserException;

public class TestUser {
	private static UserMasterServices services;

	@BeforeClass
	public static void initialize() {
		services = new UserMasterServicesImpl();

	}

	@Test
	public void testGetUserDetails() {
		try {
			User user = services.getUserDetails("a");
			String actualPassword = "a";
			Assert.assertEquals(user.getPassword(), actualPassword);
		} catch (UserException e) {
			e.printStackTrace();
		}
	}

}
