package com.cg.appl.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.appl.entities.BillDetails;
import com.cg.appl.entities.Consumers;
import com.cg.appl.entities.User;
import com.cg.appl.exceptions.UserException;
import com.cg.appl.util.JndiUtil;

public class UserMasterDaoImpl implements UserMasterDao {
	private JndiUtil util;

	public UserMasterDaoImpl() {
		util = new JndiUtil(); // constructor to make obj of Jdbcutil
	}
	@Override
	public boolean isUserAuthenticated(String userName, String password)
			throws UserException {
		User user = getUserDetails(userName);
		if (password.equals(user.getPassword())) {
			return true;
		} else {
			return false;
		}
	}
	@Override
	public User getUserDetails(String userName) throws UserException {
		Connection connect = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String query = "SELECT PASSWORD, USERFNAME FROM USERS WHERE USERNAME=?";
		try {
			connect = JndiUtil.obtainConnection();
			stmt = connect.prepareStatement(query);
			stmt.setString(1, userName);

			rs = stmt.executeQuery();

			if (rs.next()) {
				String password = rs.getString("PASSWORD");
				String fullname = rs.getString("USERFNAME");
				User user = new User(userName, password, fullname);
				System.out.println(user);
				return user;
			} else {
				throw new UserException("Username Wrong!!");
			}
		} catch (SQLException e) {
			throw new UserException("JDBC failed", e);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (stmt != null) {
					stmt.close();
				}
				if (connect != null) {
					connect.close();
				}
			} catch (SQLException e) {
				throw new UserException(" JDBC connection closing failed!!");
			}
		}
	}

	@Override
	public int addBillDetails(BillDetails bd) throws UserException{
		Connection connect = null;
		PreparedStatement pstm = null;
		int msg=0;
		int billId = getBillid();
		String query = "INSERT INTO BILLDETAILS VALUES(?,?,?,?,?,?)";
		
		try {
			connect = JndiUtil.obtainConnection();
			pstm = connect.prepareStatement(query);
			
			pstm.setInt(1,billId);
			pstm.setInt(2, bd.getConsumer_num());
			pstm.setFloat(3, bd.getCur_reading());
			pstm.setFloat(4, bd.getUnitConsumed());
			pstm.setFloat(5, bd.getNetAmount());
			pstm.setDate(6, bd.getBill_date());
			int status = pstm.executeUpdate();
			if(status > 0 ){
				msg = billId;
			}else{
				System.out.println("failed insertion");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return msg;
	}
	@Override
	public List<Consumers> showAll() throws UserException {
		Connection conn = null;
		PreparedStatement pstm = null;
		List<Consumers> cList = new ArrayList<Consumers>();
		String query = "select consumer_num, consumer_name, address FROM consumers";
		try {
			conn = JndiUtil.obtainConnection();
			pstm = conn.prepareStatement(query);
			ResultSet res = pstm.executeQuery();
			while (res.next()) {
				Consumers c = new Consumers();
				c.setConsumer_num(res.getInt("consumer_num"));
				c.setConsumer_name(res.getString("consumer_name"));
				c.setAddress(res.getString("address"));
				
				cList.add(c);
			}
		} catch (UserException | SQLException e) {
			e.printStackTrace();
			throw new UserException("Problem in show");
		}

		return cList;
	}
	@Override
	public List<BillDetails> showBilDetails(int consumerid) throws UserException {
		System.out.println("In Show details...");
		Connection conn = null;
		PreparedStatement pstm = null;
		List<BillDetails> cList = new ArrayList<BillDetails>();
		String query = "select Bill_num, cur_reading, unitconsumed, netamount, bill_date FROM BILLDETAILS where consumer_num=?";
		try {
			conn = JndiUtil.obtainConnection();
			pstm = conn.prepareStatement(query);
			
			pstm.setInt(1, consumerid);
			ResultSet res = pstm.executeQuery();
			while (res.next()) {
				BillDetails bill = new BillDetails();
				bill.setBill_num(res.getInt("Bill_num"));
				bill.setCur_reading(res.getFloat("cur_reading"));
				bill.setUnitConsumed(res.getFloat("unitconsumed"));
				bill.setNetAmount(res.getFloat("netamount"));
				bill.setBill_date(res.getDate("bill_date"));
				cList.add(bill);
				System.out.println("list:"+cList);
			}
		}catch (UserException | SQLException e) {
			e.printStackTrace();
			throw new UserException("Problem in show");
		}

		return cList;
	}

	public int getBillid() {
		Connection connect = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		int billId=0;
		String query = "SELECT seq_bill_num.NEXTVAL from dual";
		try {
			connect = JndiUtil.obtainConnection();
			stmt = connect.prepareStatement(query);
			rs = stmt.executeQuery();
			billId =0;
			if (rs.next()) {
				
				billId = rs.getInt(1);
				
		
			} 
		} catch (UserException |SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return billId;
	
	}

	public int isvalid(int cnumber){
	Connection connect = null;
	PreparedStatement stmt = null;
	ResultSet rs = null;
	int consumer_no=0;
	String query = "SELECT CONSUMER_NUM FROM CONSUMERS WHERE CONSUMER_NUM=?";
	try {
		connect = JndiUtil.obtainConnection();
		stmt = connect.prepareStatement(query);
		stmt.setInt(1, cnumber);
		ResultSet res = stmt.executeQuery();

		while (res.next()) {
			consumer_no = res.getInt(1);
			System.out.println("consumer_no "+consumer_no);
		}
	} catch (SQLException | UserException e) {
	
		e.printStackTrace();
	} finally {
		try {
			connect.close();
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	return consumer_no;


}

	

	
}


