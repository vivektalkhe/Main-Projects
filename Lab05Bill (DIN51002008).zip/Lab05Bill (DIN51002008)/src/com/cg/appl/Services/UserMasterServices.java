package com.cg.appl.Services;

import java.util.List;

import com.cg.appl.entities.BillDetails;
import com.cg.appl.entities.Consumers;
import com.cg.appl.entities.User;
import com.cg.appl.exceptions.UserException;


public interface UserMasterServices {
	User getUserDetails(String userName) throws UserException;
	boolean isUserAuthenticated(String userName, String password) throws UserException;
	int addBillDetails(BillDetails bd) throws UserException;
	List<Consumers> ShowAll() throws UserException;
	List<BillDetails> showBilDetails(int consumerid)throws UserException;
}
