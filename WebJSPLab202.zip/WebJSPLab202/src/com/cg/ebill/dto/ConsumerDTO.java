package com.cg.ebill.dto;

public class ConsumerDTO {

	private Long consumerNo;
	private String consumerName, consumerAddress;
		
	public ConsumerDTO() {
		
	}

	public ConsumerDTO(Long consumerNo, String consumerName,
			String consumerAddress) {
		super();
		this.consumerNo = consumerNo;
		this.consumerName = consumerName;
		this.consumerAddress = consumerAddress;
	}

	public Long getConsumerNo() {
		return consumerNo;
	}

	public void setConsumerNo(Long consumerNo) {
		this.consumerNo = consumerNo;
	}

	public String getConsumerName() {
		return consumerName;
	}

	public void setConsumerName(String consumerName) {
		this.consumerName = consumerName;
	}

	public String getConsumerAddress() {
		return consumerAddress;
	}

	public void setConsumerAddress(String consumerAddress) {
		this.consumerAddress = consumerAddress;
	}
}