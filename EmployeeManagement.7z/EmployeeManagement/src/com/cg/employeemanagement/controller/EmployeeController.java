package com.cg.employeemanagement.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.exception.EmployeeException;
import com.cg.employeemanagement.service.EmployeeServiceImpl;
import com.cg.employeemanagement.service.IEmployeeService;


@WebServlet("*.do")
public class EmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	IEmployeeService service;
	
	
	
	public EmployeeController() {
		service = new EmployeeServiceImpl();
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);

		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	private void processRequest(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException{
		String path=request.getServletPath();
		System.out.println(path);
		
		if(path.equals("/empCtrl.do")){
		RequestDispatcher rs = request.getRequestDispatcher("addEmployee.jsp");
		rs.forward(request, response);
		}
		if(path.equals("/empAdd.do")){
			Employee emp = new Employee();
			
			String name = request.getParameter("jname");
			String qualification= request.getParameter("jqual");
			String salary = request.getParameter("jsal");
			
		
			emp.setEmpname(name);
			emp.setEmpQualification(qualification);
			emp.setEmpSal(Double.parseDouble(salary));
			
			try {
				int empId=service.addEmployee(emp);
				request.setAttribute("id", empId);
				RequestDispatcher rs = request.getRequestDispatcher("welcome.jsp");
				rs.forward(request, response);
			} catch (EmployeeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
		else if (path.equals("/showAll.do")){
			System.out.println(path);
			List<Employee> myList = null;
			try {
				myList= service.showAll();
				//System.out.println(myList);
				
			} catch (EmployeeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			request.setAttribute("data", myList);
			RequestDispatcher req = request.getRequestDispatcher("showAll.jsp");
			req.forward(request, response);
		}
		
		else if(path.equals("/update.do")){
			 String data =request.getQueryString();
			 
			 String empid = data.substring(3,7);
			
			int id=Integer.parseInt(empid);
			Employee eData =service.getEmployeeDetails(id);
			System.out.println(eData);
			request.setAttribute("empData", eData);
			RequestDispatcher rd = request.getRequestDispatcher("updateEmployee.jsp");
			rd.forward(request, response);
		
		}
		
		else if(path.equals("/updateData.do")){
			
			List<Employee> upList = new ArrayList<>();
			int id = Integer.parseInt(request.getParameter("uid"));
			System.out.println(id);
			String name=request.getParameter("uname");
			String qual=request.getParameter("uqual");
			double sal=Double.parseDouble(request.getParameter("usal"));
			Employee emp = new Employee(id,name,qual,sal);
			
			
			
			try {
				if(service.updateEmployee(emp)){
					System.out.println("updated");
					upList=service.showAll();
					request.setAttribute("data", upList);
					RequestDispatcher rd = request.getRequestDispatcher("showAll.jsp");
					rd.forward(request, response);
					
				}
			} catch (EmployeeException e) {
				System.out.println("controller not updated");
			}
			
		}
		
		else if(path.equals("/delete.do")){
			Employee eData = new Employee();
			List<Employee> delList = new ArrayList<>();
			String data =request.getQueryString().substring(3,7);
			int id=Integer.parseInt(data);
			eData.setEmpId(id);
			
			
			String data1 =request.getQueryString().substring(3,7);
			eData.setEmpname(data1);
			
			String data2 =request.getQueryString().substring(3,7);
			eData.setEmpQualification(data2);
			
			
			String data3 =request.getQueryString().substring(3,7);
			int sal=Integer.parseInt(data3);
			eData.setEmpSal(sal);
			try {
				if(service.deleteEmployee(eData)){
					delList = service.showAll();
					request.setAttribute("data", delList);
					RequestDispatcher rd = request.getRequestDispatcher("showAll.jsp");
					rd.forward(request, response);
				}
			} catch (EmployeeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			/*request.setAttribute("empData", eData);
			RequestDispatcher rd = request.getRequestDispatcher("showAll.jsp");
			rd.forward(request, response);*/
		}
	}
}
