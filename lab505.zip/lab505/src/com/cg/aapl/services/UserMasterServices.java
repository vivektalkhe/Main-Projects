package com.cg.aapl.services;

import com.cg.aapl.entities.Bill;
import com.cg.aapl.entities.Consumer;
import com.cg.aapl.entities.User;
import com.cg.aapl.exceptions.UserException;

public interface UserMasterServices {
	User getUserDetails(String UserName) throws UserException;
	boolean isUserAuthenticated(String UserName, String password) throws UserException;
	int insertBill(Bill bill) throws UserException;
	boolean isValid(int consumerNumber) throws UserException;
	
	
	
}
