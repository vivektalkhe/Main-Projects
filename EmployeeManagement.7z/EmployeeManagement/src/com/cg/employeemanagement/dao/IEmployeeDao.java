package com.cg.employeemanagement.dao;

import java.util.List;

import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.exception.EmployeeException;

public interface IEmployeeDao {

public int addEmployee(Employee emp) throws EmployeeException;
	
	public List<Employee> showAll() throws EmployeeException;
	
	public Employee getEmployeeDetails(int id);
	
	public boolean updateEmployee(Employee emp) throws EmployeeException;
	
	public boolean deleteEmployee(Employee emp) throws EmployeeException;
}
