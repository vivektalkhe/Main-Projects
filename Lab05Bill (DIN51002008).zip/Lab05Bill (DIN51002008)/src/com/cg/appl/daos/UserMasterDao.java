package com.cg.appl.daos;

import java.util.List;

import com.cg.appl.entities.BillDetails;
import com.cg.appl.entities.Consumers;
import com.cg.appl.entities.User;
import com.cg.appl.exceptions.UserException;

public interface UserMasterDao {
	
	User getUserDetails(String userName) throws UserException;
	boolean isUserAuthenticated(String userName, String password) throws UserException;
	int addBillDetails(BillDetails bd) throws UserException;
	List<Consumers> showAll() throws UserException;
	List<BillDetails> showBilDetails(int consumerid) throws UserException;
}
