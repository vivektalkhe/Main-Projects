package com.cg.app.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.appl.util.JndiUtil;

public class Mydate {
	private JndiUtil jdbcUtill = new JndiUtil();

	public Boolean insertdate(Date d) {
		PreparedStatement stat = null;
		Connection connection = null;
		ResultSet rs = null;

		String Query = "insert into mydate values(?) ";
		try {

			connection = jdbcUtill.getConnection();
			stat = connection.prepareStatement(Query);
			stat.setDate(1, d);
			rs = stat.executeQuery();
			if (rs.next()) {
				System.out.println("INSERTED");
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			return false;

		}

	}

	public List<java.sql.Date> getDate() {

		List<java.sql.Date> list =new ArrayList<java.sql.Date>();
		PreparedStatement stat = null;
		Connection connection = null;
		ResultSet rs = null;

		String Query = "select * from mydate ";
		try {

			connection = jdbcUtill.getConnection();
			stat = connection.prepareStatement(Query);
			rs = stat.executeQuery();
			while (rs.next()) {
				java.sql.Date d = rs.getDate(1);
				list.add(d);
			} 
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
		return null;

		}

	}
}
